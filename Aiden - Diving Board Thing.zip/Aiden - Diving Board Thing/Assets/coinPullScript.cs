﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class coinPullScript : MonoBehaviour
{

    Rigidbody rb;
    public GameObject harvCube;
    public float forceModifier = 0;

    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody>();
        harvCube = GameObject.Find("steveCube");
    }

    // Update is called once per frame
    void Update()
    {
        Vector3 playerVector = transform.position - harvCube.transform.position;
        float force = forceModifier / playerVector.magnitude;
        rb.AddForce(-playerVector.normalized * force);


    }
}
