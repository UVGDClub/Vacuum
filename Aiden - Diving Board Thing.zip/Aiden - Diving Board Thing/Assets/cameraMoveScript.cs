﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class cameraMoveScript : MonoBehaviour
{

    public GameObject harvCube;
    public GameObject floor;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        Vector3 direction = (harvCube.transform.position - floor.transform.position).normalized;
        transform.position = harvCube.transform.position + direction * 20;
        transform.forward = -direction;
        RaycastHit[] hits;
        hits = Physics.RaycastAll(harvCube.transform.position, direction, 25f);

        for(int i=0; i<hits.Length; i++)
        {
            if(hits[i].transform.gameObject.tag == "wall")
            {
                transform.position = harvCube.transform.position + direction * hits[i].distance;
            }
        }
        
    }
}
