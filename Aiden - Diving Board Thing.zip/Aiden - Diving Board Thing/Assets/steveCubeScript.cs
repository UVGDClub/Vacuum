﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class steveCubeScript : MonoBehaviour
{

    public Rigidbody rb;
    public bool jumped;
    public GameObject camera;
    public GameObject[] coins;
    

    // Start is called before the first frame update
    void Start()
    {
        rb = gameObject.GetComponent<Rigidbody>();
        jumped = false;
        
    }

    // Update is called once per frame
    void Update()
    {

        Vector3 forward = camera.transform.forward;
        Vector3 right = camera.transform.right;

        forward.y = 0f;
        right.y = 0f;

        forward = forward.normalized;
        right = right.normalized;

        int vertical = 0;
        int horizontal = 0;

        if(Input.GetKey(KeyCode.W)){
            vertical++;
        }
        if (Input.GetKey(KeyCode.S))
        {
            vertical--;
        }
        if (Input.GetKey(KeyCode.A))
        {
            horizontal--;
        }
        if (Input.GetKey(KeyCode.D))
        {
            horizontal++;
        }

        if (Input.GetKeyDown(KeyCode.Space) && !jumped){
            Debug.Log("spaaaaaaaaaaace");

            float x;
            float y;
            float z;

            if (horizontal == 0)
            {
                x = Random.Range(-5, 5);
            }
            else
            {
                x = Random.Range(5, 10) * horizontal;
            }
            y = Random.Range(10, 20);
            if (vertical == 0)
            {
                z = Random.Range(-5, 5);
            }
            else
            {
                z = Random.Range(5, 10) * vertical;
            }

            rb.velocity = forward * z + right * x + Vector3.up * y;

            // rb.velocity = new Vector3(x, y, z);

            x = Random.Range(-10, 10);
            y = Random.Range(-10, 10);
            z = Random.Range(-10, 10);

            rb.angularVelocity = new Vector3(x, y, z);

            //jumped = true;

            
        }
    }

    private void OnTriggerEnter(Collider c)
    {
        if (c.gameObject.tag == "coin")
        {
            Destroy(c.gameObject);
        }
    }

}
