﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class coinScript : MonoBehaviour
{

    public int NUM_COINS;
    public int RADIUS;

    public GameObject coin;

    public GameObject[] coins;

    public GameObject harvCube;

    // Start is called before the first frame update
    void Start()
    {
        coins = new GameObject[NUM_COINS];

        for(int i=0; i<NUM_COINS; i++)
        {
            float x = Random.Range(-100, 100);
            float z = Random.Range(-100, 100);
            float y = Random.Range(-100, 100);

            Vector3 location = new Vector3(x, y, z);
            location = location.normalized * Random.Range(0, RADIUS);

            GameObject newCoin = GameObject.Instantiate(coin, location, new Quaternion(0,0,0,0), transform);
            coins[i] = newCoin;
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
